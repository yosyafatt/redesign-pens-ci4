<?= $this->extend('templates/base'); ?>

<?= $this->section('content'); ?>

<section class="page-header">
    <div class="container">
        <div class="row">
            <div class="col-md-4 order-last">
                <h1 class="heading text-white">
                    Berita
                </h1>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?= base_url(); ?>">Beranda</a></li>
                    <li class="breadcrumb-item"><a href="#">Berita</a></li>
                </ol>
            </div>
            <div class="col-md-8">
                <div class="carousel slide" id="carouselberita" data-ride="carousel">
                    <div class="carousel-inner">
                        <ol class="carousel-indicators">
                            <li data-target="#carouselberita" data-slide-to="0" class="active"></li>
                            <li data-target="#carouselberita" data-slide-to="1"></li>
                            <li data-target="#carouselberita" data-slide-to="2"></li>
                        </ol>
                        <div class="carousel-item active" data-interval="5000">
                            <img src="<?= base_url(); ?>/img/berita/1.jpeg" alt="" class="d-block">
                            <div class="carousel-caption d-none d-md-block">
                                <h3>/img/berita/1.jpeg</h3>
                                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Beatae, similique.</p>
                            </div>
                        </div>
                        <div class="carousel-item" data-interval="5000">
                            <img src="<?= base_url(); ?>/img/berita/2.jpg" alt="" class="d-block">
                            <div class="carousel-caption d-none d-md-block">
                                <h3>/img/berita/2.jpg</h3>
                                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Beatae, similique.</p>
                            </div>
                        </div>
                        <div class="carousel-item" data-interval="5000">
                            <img src="<?= base_url(); ?>/img/berita/3.jpg" alt="" class="d-block">
                            <div class="carousel-caption d-none d-md-block">
                                <h3>/img/berita/3.jpg</h3>
                                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Beatae, similique.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<main class="main-content berita">
    <div class="container">
        <div class="row mb-5">
            <div class="col-md-8">
                <section>
                    <h3 class="heading mb-4">Berita Terkini</h3>
                    <div class="row row-cols-3">
                        <div class="col mb-4">
                            <div class="card">
                                <img src="<?= base_url(); ?>/img/berita/5.jpeg" class="card-img-top" alt="...">
                                <div class="card-body">
                                    <a href="" class="text-decoration-none">
                                        <h6 class="heading card-title">Terapkan Kenormalan Baru, Mahasiswa dan Tamu PENS Wajib Gunakan Face Shield</h5>
                                    </a>
                                    <p class="card-text">
                                        <small class="text-muted">Senin, 15 Jun 2020</small>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col mb-4">
                            <div class="card">
                                <img src="<?= base_url(); ?>/img/berita/6.jpg" class="card-img-top" alt="...">
                                <div class="card-body">
                                    <h6 class="heading card-title">Jawab Tantangan Kurang Akuratnya Thermo Gun, Tiga Mahasiswa PENS Ciptakan Descotin yang Mampu Ukur Suhu Tubuh dengan Melintas di Depan Kamera</h5>
                                        <p class="card-text">
                                            <small class="text-muted">Senin, 15 Jun 2020</small>
                                        </p>
                                </div>
                            </div>
                        </div>
                        <div class="col mb-4">
                            <div class="card">
                                <img src="<?= base_url(); ?>/img/berita/7.jpeg" class="card-img-top" alt="...">
                                <div class="card-body">
                                    <h6 class="heading card-title">Tim Gena PENS Jadi Pembicara di Talkshow Muda Luar Biasa, Radio Suara Surabaya</h5>
                                        <p class="card-text">
                                            <small class="text-muted">Senin, 15 Jun 2020</small>
                                        </p>
                                </div>
                            </div>
                        </div>
                        <div class="col mb-4">
                            <div class="card">
                                <img src="<?= base_url(); ?>/img/berita/7.jpeg" class="card-img-top" alt="...">
                                <div class="card-body">
                                    <h6 class="heading card-title">Tim Gena PENS Jadi Pembicara di Talkshow Muda Luar Biasa, Radio Suara Surabaya</h5>
                                        <p class="card-text">
                                            <small class="text-muted">Senin, 15 Jun 2020</small>
                                        </p>
                                </div>
                            </div>
                        </div>
                        <div class="col mb-4">
                            <div class="card">
                                <img src="<?= base_url(); ?>/img/berita/7.jpeg" class="card-img-top" alt="...">
                                <div class="card-body">
                                    <h6 class="heading card-title">Tim Gena PENS Jadi Pembicara di Talkshow Muda Luar Biasa, Radio Suara Surabaya</h5>
                                        <p class="card-text">
                                            <small class="text-muted">Senin, 15 Jun 2020</small>
                                        </p>
                                </div>
                            </div>
                        </div>
                        <div class="col mb-4">
                            <div class="card">
                                <img src="<?= base_url(); ?>/img/berita/7.jpeg" class="card-img-top" alt="...">
                                <div class="card-body">
                                    <h6 class="heading card-title">Tim Gena PENS Jadi Pembicara di Talkshow Muda Luar Biasa, Radio Suara Surabaya</h5>
                                        <p class="card-text">
                                            <small class="text-muted">Senin, 15 Jun 2020</small>
                                        </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <section class="mt-5">
                    <h3 class="heading mb-4">PENS TV</h3>

                </section>
            </div>

            <div class="col-md-4 pr-0">
                <section class="mb-4">
                    <ul class="nav nav-tabs nav-fill" id="myTab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <a class="nav-link active heading" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">Agenda</a>
                        </li>
                        <li class="nav-item" role="presentation">
                            <a class="nav-link heading" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Pengumuman</a>
                        </li>
                    </ul>
                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">...</div>
                        <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">...</div>
                    </div>
                </section>
                <section class="berita arsip-berita">
                    <h4 class="heading">Arsip Berita</h4>
                    <ul class="list-group list-group-flush">
                        <a href="#" class="list-group-item list-group-item-action">
                            Juni 2020 <span class="badge badge-pill">9</span>
                        </a>
                        <a href="#" class="list-group-item list-group-item-action">
                            Mei 2020 <span class="badge badge-pill">14</span>
                        </a>
                        <a href="#" class="list-group-item list-group-item-action">
                            April 2020 <span class="badge badge-pill">11</span>
                        </a>
                        <a href="#" class="list-group-item list-group-item-action">
                            Maret 2020 <span class="badge badge-pill">8</span>
                        </a>
                        <a href="#" class="list-group-item list-group-item-action">
                            Februari 2020 <span class="badge badge-pill">18</span>
                        </a>
                    </ul>
                </section>
            </div>
        </div>
    </div>
</main>

<?= $this->endSection(); ?>