<?= $this->extend('admin/base'); ?>

<?= $this->section('content'); ?>
<h3>index</h3>



<?= $this->endSection(); ?>