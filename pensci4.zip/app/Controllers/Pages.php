<?php

namespace App\Controllers;

use CodeIgniter\Debug\Toolbar\Collectors\Views;

class Pages extends BaseController
{

    public function __construct()
    {
    }

    public function index()
    {
        $data = [
            'title' => '',
            'page_name' => 'beranda',
        ];
        return view('pages/beranda', $data);
    }

    public function akademik()
    {
        $data = [
            'title' => 'Akademik - ',
            'page_name' => 'akademik',
        ];
        return view('pages/akademik', $data);
    }

    public function layanan()
    {
        $data = [
            'title' => 'Layanan - ',
            'page_name' => 'layanan',
        ];
        return view('pages/layanan', $data);
    }

    public function tentang()
    {
        $data = [
            'title' => 'Tentang PENS - ',
            'page_name' => 'tentang',
        ];
        return view('pages/tentang', $data);
    }

    public function berita()
    {
        $data = [
            'title' => 'Berita - ',
            'page_name' => 'berita',
        ];
        return view('pages/berita', $data);
    }
}
