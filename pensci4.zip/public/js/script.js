$(document).ready(function () {
  $(".owl-carousel").owlCarousel({
    loop: true,
    margin: 16,
    items: 1,
    autoplay: true,
    autoplayTimeout: 7000,
    autoplayHoverPause: false,
    //   responsive: {
    //     0: {
    //       items: 1,
    //     },
    //     600: {
    //       items: 3,
    //     },
    //     1000: {
    //       items: 5,
    //     },
    //   },
  });
});
